package javafxsgemec.dao;

public class RefaccionCompradaDAO {
    
}
