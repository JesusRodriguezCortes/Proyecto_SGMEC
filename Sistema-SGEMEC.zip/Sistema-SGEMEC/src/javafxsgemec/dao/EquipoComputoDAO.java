package javafxsgemec.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafxsgemec.pojo.EquipoComputo;
import javafxsgemec.connectionBD.OpenConnection;
import javafxsgemec.connectionBD.ConstantsConnection;

public class EquipoComputoDAO {
    public void crearEquipoComputo(){
        
    }
    
    public void consultEquipoComputo(){
        
    }
    
    public void consultEquiposComputo(){
        
    }
    
    public void modificarEquipoComputo(){
        
    }
    
    public void deleteEquipoComputo(){
        
    }
}
