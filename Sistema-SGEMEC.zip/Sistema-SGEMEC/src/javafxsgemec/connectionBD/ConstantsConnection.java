package javafxsgemec.connectionBD;

public class ConstantsConnection {
    public static final int CODIGO_OPERACION_CORRECTA = 100;
    public static final int CODIGO_ERROR_CONEXIONDB = 200;
    public static final int CODIGO_OPERACION_DML_FALLIDA = 201;
    public static final int CODIGO_CREDENCIALES_INCORRECTAS = 202;
}