package javafxsgemec.pojo;

public class EstadoDispositivo {
    public static final int ENVIADO_CLIENTE = 1;
    public static final int RECIBIDO_EMPRESA = 2;
    public static final int VALORACION = 3;
    public static final int REPARACION = 4;
    public static final int EMPAQUETADO = 5;
    public static final int ENVIADO_EMPRESA = 6;
    public static final int RECIBIDO_CLIENTE = 7;
}
